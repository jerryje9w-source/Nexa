<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GameLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'game_prize_id',
        'amount_won',
    ];

    /**
     * Get the user that owns the game log.
     */
    public function user()
    {
        // User মডেলের সাথে রিলেশনশিপ তৈরি করা হলো
        return $this->belongsTo(User::class);
    }

    /**
     * Get the prize for the log.
     */
    public function gamePrize()
    {
        return $this->belongsTo(GamePrize::class);
    }
}