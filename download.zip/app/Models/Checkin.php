<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Checkin extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',     // ✅ user_id allow করা হলো
        'bonus_amount',
        'checkin_date',
        // অন্য কলাম থাকলে সেগুলোও এখানে যোগ করো
    ];
}
