<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserLedger extends Model
{
    use HasFactory;

    protected $table = 'user_ledgers';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'user_id',
        'type',
        'amount',
        'trx_type',
        'remarks',
        'final_balance',
        'status',
        // ✅ 'date' কলামটি এখান থেকে সরিয়ে দেওয়া হয়েছে।
        // Laravel এখন নিজে থেকে 'created_at' কলামে সময় যোগ করবে।
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}