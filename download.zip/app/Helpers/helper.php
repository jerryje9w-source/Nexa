<?php

use App\Models\User;
use App\Models\Deposit;
use App\Models\UserLedger;

if (!function_exists('get_team_stats')) {
    function get_team_stats($userId)
    {
        $user = User::find($userId);
        if (!$user) return null;

        // লেভেল ১
        $level1 = User::where('ref_by', $user->ref_id)->get();
        $level1_ids = $level1->pluck('id');

        // লেভেল ২
        $level2 = User::whereIn('ref_by', $level1->pluck('ref_id'))->get();
        $level2_ids = $level2->pluck('id');

        // লেভেল ৩
        $level3 = User::whereIn('ref_by', $level2->pluck('ref_id'))->get();
        $level3_ids = $level3->pluck('id');

        $team_size = count($level1) + count($level2) + count($level3);

        $deposit = Deposit::whereIn('user_id', array_merge($level1_ids->toArray(), $level2_ids->toArray(), $level3_ids->toArray()))
                          ->where('status', 'approved')->sum('amount');

        $level1_deposit = Deposit::whereIn('user_id', $level1_ids)->where('status', 'approved')->sum('amount');
        $level2_deposit = Deposit::whereIn('user_id', $level2_ids)->where('status', 'approved')->sum('amount');
        $level3_deposit = Deposit::whereIn('user_id', $level3_ids)->where('status', 'approved')->sum('amount');

        return [
            'level1_users' => $level1,
            'level2_users' => $level2,
            'level3_users' => $level3,
            'size' => $team_size,
            'deposit' => $deposit,
            'level1_deposit' => $level1_deposit,
            'level2_deposit' => $level2_deposit,
            'level3_deposit' => $level3_deposit,
        ];
    }
}
