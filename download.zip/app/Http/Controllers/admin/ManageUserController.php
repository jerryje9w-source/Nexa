<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Bonus;
use App\Models\Deposit;
use App\Models\Mining;
use App\Models\Purchase;
use App\Models\Usdt;
use App\Models\User;
use App\Models\UserLedger;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class ManageUserController extends Controller
{
    // ... আপনার অন্যান্য সব ফাংশন এখানে থাকবে ...
    // ... (customers, user_acc_login, etc. যেমন ছিল তেমনই থাকবে) ...

    // শুধুমাত্র paymentStatus ফাংশনটি নিচে দেওয়া হলো।
    // আপনি চাইলে শুধু এই ফাংশনটি পরিবর্তন করতে পারেন অথবা পুরো ফাইলটিই প্রতিস্থাপন করতে পারেন।

    public function customers()
    {
        $users = User::where('id', '!=', '1')->orderByDesc('id')->paginate(20);
        return view('admin.pages.users.users', compact('users'));
    }

    public function customizationBalance(Request $request, $condion)
    {
        $user = User::find($request->user_id);
        if ($user) {
            if ($condion == 'plus') {
                $user->balance += $request->plus;
            }
            if ($condion == 'minus') {
                $user->balance -= $request->minus;
            }
            $user->save();
        }
        return back()->with('success', 'Balance customization success');
    }

    public function customizationBalancewwww(Request $request, $condion)
    {
        $user = User::find($request->user_id);
        if ($user) {
            if ($condion == 'plus') {
                $user->balance += $request->plus;
            }
            if ($condion == 'minus') {
                $user->balance -= $request->minus;
            }
            $user->save();
        }
        return back()->with('success', 'Withdraw balance customization success');
    }

    public function customersStatus($id)
    {
        $user = User::find($id);
        if ($user) {
            $user->status = $user->status == 'active' ? 'inactive' : 'active';
            $user->save();
        }
        return redirect()->back()->with('success', 'Successfully changed user status.');
    }

    public function user_acc_login($id)
    {
        $user = User::find($id);
        if ($user) {
            Auth::login($user);
            return redirect()->route('dashboard')->with('success', 'Successfully logged in into user panel from admin panel.');
        }
        abort(403);
    }

    public function user_acc_password(Request $request)
    {
        $user = User::find($request->id);
        if ($user) {
            $user->password = Hash::make($request->password);
            $user->save();
        } else {
            abort(403);
        }
        return response()->json(['status' => true, 'message' => 'Successfully user password set again.']);
    }

    public function pendingPayment()
    {
        $title = 'Pending';
        $payments = Deposit::with('user')->where('status', 'pending')->orderByDesc('id')->get();
        return view('admin.pages.payment.list', compact('payments', 'title'));
    }

    public function rejectedPayment()
    {
        $title = 'Rejected';
        $payments = Deposit::with('user')->where('status', 'rejected')->orderByDesc('id')->get();
        return view('admin.pages.payment.list', compact('payments', 'title'));
    }

    public function approvedPayment()
    {
        $title = 'Approved';
        $payments = Deposit::with('user')->where('status', 'approved')->orderByDesc('id')->get();
        return view('admin.pages.payment.list', compact('payments', 'title'));
    }

    /**
     * ======================================================================
     * ✅ ভাই, এইবার দেখুন। এখানে 'reason' বা 'date' কলাম ব্যবহার করার কোনো সুযোগই নেই।
     * ======================================================================
     */
    public function paymentStatus(Request $request, $id)
    {
        $payment = Deposit::find($id);
        if (!$payment) { return redirect()->back()->with('error', 'Payment not found.'); }

        $user = User::find($payment->user_id);
        if (!$user) { return redirect()->back()->with('error', 'User not found.'); }

        // ব্যালেন্স আপডেট
        if ($request->status == 'approved' && $payment->status != 'approved') {
            $user->balance += $payment->final_amount;
            $user->save();
        } elseif ($request->status == 'rejected' && $payment->status == 'approved') {
            $user->balance -= $payment->final_amount;
            $user->save();
        }

        // নতুন এবং সবচেয়ে বেসিক পদ্ধতিতে লেজার সেভ করা হচ্ছে
        $ledger = new UserLedger();
        $ledger->user_id = $payment->user_id;
        $ledger->type = 'deposit'; // 'reason' এর পরিবর্তে 'type'
        $ledger->amount = $payment->final_amount;
        $ledger->trx_type = ($request->status == 'approved') ? '+' : '!';
        $ledger->remarks = 'Deposit request has been ' . $request->status . '.'; // 'perticulation' এর পরিবর্তে 'remarks'
        $ledger->final_balance = $user->balance;
        $ledger->status = $request->status;
        // ❌ 'date' কলাম এখানে সেট করা হচ্ছে না। Laravel নিজে থেকে created_at ব্যবহার করবে।
        $ledger->save();

        // পেমেন্ট স্ট্যাটাস আপডেট
        $payment->status = $request->status;
        $payment->save();

        return redirect()->back()->with('success', 'Payment status changed successfully.');
    }

    // ... আপনার বাকি সব ফাংশন যেমন ছিল তেমনই থাকবে ...
    public function search()
    {
        return view('admin.pages.users.search');
    }

    public function searchSubmit(Request $request)
    {
        if ($request->search) {
            $user = User::where('phone', $request->search)->orWhere('ref_id', $request->search)->first();
            if ($user) {
                return view('admin.pages.users.search', compact('user'));
            }
        }
        return redirect()->route('admin.search.user')->with('error', 'OOPs User not found.');
    }

    public function purchaseRecord()
    {
        $purchases = Purchase::with(['user', 'package'])->orderByDesc('id')->paginate(25);
        return view('admin.pages.users.purchase-record', compact('purchases'));
    }

    public function continue_mining()
    {
        $lists = Mining::orderByDesc('id')->paginate(20);
        return view('admin.pages.mining.index', compact('lists'));
    }

    public function bonusCode(Request $request)
    {
        $bonus = Bonus::where('code', trim($request->bonus))->first();
        if ($bonus) {
            if ($bonus->status == 'active') {
                User::where('id', $request->id)->update(['bonus_code' => trim($request->bonus)]);
                return response()->json(['status' => true, 'message' => 'Successfully sent bonus code.']);
            } else {
                return response()->json(['status' => false, 'message' => 'Bonus code not activated.']);
            }
        } else {
            return response()->json(['status' => false, 'message' => 'Bonus not found.']);
        }
    }

    public function usdtPayment()
    {
        $title = 'USDT';
        return view('admin.pages.payment.usdt', compact('title'));
    }

    public function usdtPaymentChangeStatus($id, $status)
    {
        $usdt = Usdt::with('user')->find($id);
        if (!$usdt) {
            return back()->with('error', 'USDT payment not found.');
        }

        if ($status == 'approved' && $usdt->status != 'approved') {
            $usdt->user->balance += $usdt->amount * setting('rate');
            $usdt->user->save();
            $usdt->status = 'approved';
            $usdt->save();
        }

        if ($status == 'rejected') {
            if ($usdt->status == 'approved') {
                $usdt->user->balance -= $usdt->amount * setting('rate');
                $usdt->user->save();
            }
            $usdt->status = 'rejected';
            $usdt->save();
        }
        return back()->with('success', 'Status changed successfully.');
    }
}