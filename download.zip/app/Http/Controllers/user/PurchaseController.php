<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\Package;
use App\Models\Purchase;
use App\Models\User;
use App\Models\UserLedger;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PurchaseController extends Controller
{
    public function purchase_vip($id)
    {
        $vip = Package::find($id);

        if (!$vip) {
            return redirect()->route('vip')->with('error', "VIP package not found.");
        }

        if ($vip->is_default == 1)
        {
            return redirect()->route('vip')->with('error', "This VIP is default when you registered in our platform");
        }

        $v = Purchase::where('user_id', Auth::id())->where('package_id', $vip->id)->where('status', 'active')->first();
        if ($v){
            return redirect()->route('vip')->with('error', "You have already activated this VIP package.");
        }

        return view('app.main.my_vip.vip_details', compact('vip'));
    }

    public function purchaseConfirmation($id)
    {
        $package = Package::find($id);
        $user = Auth::user();
        
        // ১. প্যাকেজ চেক
        if (!$package || $package->status != 'active') {
            return response()->json(['status' => 'error', 'msg' => "This package is currently unavailable."]);
        }

        // ২. অলরেডি কেনা আছে কি না চেক
        $alreadyPurchased = Purchase::where('user_id', $user->id)
                                    ->where('package_id', $package->id)
                                    ->where('status', 'active') 
                                    ->exists(); 
        if ($alreadyPurchased) {
            return response()->json(['status' => 'error', 'msg' => "You have already purchased this package."]);
        }

        // ৩. ব্যালেন্স চেক
        if ($package->price > $user->balance) {
            return response()->json(['status' => 'error', 'msg' => "Insufficient Balance. Please recharge."]);
        }
        
        // ব্যালেন্স কাটা
        $user->balance -= $package->price;
        $user->save();

        // পারচেজ রেকর্ড সেভ
        $purchase = new Purchase();
        $purchase->user_id = Auth::id();
        $purchase->package_id = $package->id;
        $purchase->amount = $package->price;
        $purchase->hourly = ($package->commission_with_avg_amount / $package->validity) / 24;
        $purchase->daily_income = $package->commission_with_avg_amount / $package->validity;
        $purchase->date = now()->addHours(24);
        $purchase->validity = Carbon::now()->addDays($package->validity);
        $purchase->status = 'active';
        $purchase->save();

        // রেফার কমিশন লজিক (সেম রাখা হয়েছে)
        $first_ref = $this->ref_user($user->ref_by);
        if ($first_ref) {
            $amount = ($package->price * setting('first_ref', 0)) / 100;
            if ($amount > 0) {
                $first_ref->balance += $amount;
                $first_ref->save();
                $this->createLedgerEntry($first_ref, $user, $amount, 'first');
            }

            $second_ref = $this->ref_user($first_ref->ref_by);
            if ($second_ref) {
                $amount = ($package->price * setting('second_ref', 0)) / 100;
                if ($amount > 0) {
                    $second_ref->balance += $amount;
                    $second_ref->save();
                    $this->createLedgerEntry($second_ref, $user, $amount, 'second');
                }

                $third_ref = $this->ref_user($second_ref->ref_by);
                if ($third_ref) {
                    $amount = ($package->price * setting('third_ref', 0)) / 100;
                    if ($amount > 0) {
                        $third_ref->balance += $amount;
                        $third_ref->save();
                        $this->createLedgerEntry($third_ref, $user, $amount, 'third');
                    }
                }
            }
        }

        // সফল হলে JSON রেসপন্স
        return response()->json(['status' => 'success', 'msg' => "Package purchased successfully!"]);
    }

    protected function ref_user($ref_by)
    {
        if (!$ref_by) {
            return null;
        }
        return User::where('ref_id', $ref_by)->first();
    }
    
    protected function createLedgerEntry($referrer, $referred_user, $amount, $step)
    {
        $ledger = new UserLedger();
        $ledger->user_id = $referrer->id;
        $ledger->get_balance_from_user_id = $referred_user->id;
        $ledger->reason = 'commission';
        $ledger->perticulation = 'Commission from ' . $referred_user->name;
        $ledger->amount = $amount;
        $ledger->debit = $amount; 
        $ledger->status = 'approved';
        $ledger->step = $step;
        $ledger->date = now()->format('d-m-Y H:i');
        $ledger->save();
    }
}