<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\Bonus;
use App\Models\BonusLedger;
use App\Models\Checkin;
use App\Models\UserLedger;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class GetBonusController extends Controller
{
    // Bonus claim page
    public function index()
    {
        $data = Bonus::where('status', 'active')->first();
        return view('app.main.bonus.index', compact('data'));
    }

    // Submit bonus code
    public function submitBonusCode(Request $request)
    {
        // Validation
        Validator::make($request->all(), [
            'bonus_code' => 'required|string|max:140'
        ])->validate();

        $code = $request->bonus_code;
        // বোনাস কোড দিয়ে স্পেসিফিক বোনাসটি খুঁজে বের করা ভালো
        $bonus = Bonus::where('code', $code)->where('status', 'active')->first(); 
        $user = Auth::user();

        // Check if bonus exists
        if (!$bonus) {
            // যদি কোড দিয়ে না পাওয়া যায়, তবে জেনেরিক চেক (আপনার আগের লজিক অনুযায়ী)
            $bonus = Bonus::where('status', 'active')->first();
            if (!$bonus) {
                return response()->json(['status' => false, 'message' => 'Bonus not available']);
            }
             // Check code match explicitly
            if ($code != $bonus->code) {
                return response()->json(['status' => false, 'message' => 'Code invalid']);
            }
        }

        // Check if user already claimed
        $checkBonusUses = BonusLedger::where('bonus_id', $bonus->id)
            ->where('user_id', $user->id)
            ->first();

        if ($checkBonusUses) {
            return response()->json(['status' => false, 'message' => 'Already used']);
        }

        // Check bonus counter
        if ($bonus->counter >= $bonus->set_service_counter) {
            return response()->json(['status' => false, 'message' => 'Bonus limit reached']);
        }

        // Update user balance
        $user->balance += $bonus->amount;
        $user->save();

        // Add to user ledger (ফিক্সড: create মেথডের বদলে সরাসরি অবজেক্ট ব্যবহার করা হয়েছে)
        // এটি "Field 'reason' doesn't have a default value" ইরোর সমাধান করবে
        $ledger = new UserLedger();
        $ledger->user_id = $user->id;
        $ledger->reason = 'bonus'; // এই ফিল্ডটি এখন নিশ্চিতভাবে যাবে
        $ledger->perticulation = 'Congratulations '.$user->name.' received amount of '.price($bonus->amount);
        $ledger->amount = $bonus->amount;
        $ledger->debit = $bonus->amount;
        $ledger->status = 'approved';
        $ledger->date = now()->format('d-m-Y H:i');
        $ledger->save();

        // Increment bonus counter
        $bonus->increment('counter');

        // Add to bonus ledger
        BonusLedger::create([
            'user_id' => $user->id,
            'bonus_id' => $bonus->id,
            'amount' => $bonus->amount,
            'bonus_code' => $code,
        ]);

        return response()->json(['status' => true, 'amount' => $bonus->amount]);
    }

    // Bonus record / ledger view
    public function preview()
    {
        $datas = BonusLedger::with(['bonus', 'user'])
            ->where('user_id', Auth::id())
            ->orderByDesc('id')
            ->get();

        return view('app.main.bonus.bonus-preview', compact('datas'));
    }

    // Daily checkin
    public function checkin()
    {
        $user = Auth::user();

        // আজকের দিনে কি চেকইন করেছে কিনা চেক করা
        $alreadyChecked = Checkin::where('user_id', $user->id)
            ->whereDate('created_at', now()->toDateString())
            ->exists();

        if ($alreadyChecked) {
            return redirect()->back()->with('error', 'You can only get checkin bonus once every 24 hours.');
        }

        $amount = setting('checkin'); // get amount from settings

        // নতুন চেকইন এন্ট্রি
        Checkin::create([
            'user_id' => $user->id,
            'date' => now()->addHours(24),
            'amount' => $amount,
        ]);

        // ব্যালেন্স আপডেট
        $user->increment('balance', $amount);
        
        // (অপশনাল) চেকইনের জন্যও লেজার এন্ট্রি রাখা ভালো, যাতে ভবিষ্যতে ইরোর না হয়
        // আপনি চাইলে নিচের অংশটুকু কমেন্ট আউট করে রাখতে পারেন যদি চেকইনে লেজার না লাগে
        $ledger = new UserLedger();
        $ledger->user_id = $user->id;
        $ledger->reason = 'checkin';
        $ledger->perticulation = 'Daily checkin bonus received';
        $ledger->amount = $amount;
        $ledger->debit = $amount;
        $ledger->status = 'approved';
        $ledger->date = now()->format('d-m-Y H:i');
        $ledger->save();

        return redirect()->back()->with('success', 'You have received daily checkin bonus: ' . price($amount));
    }

    // Checkin ledger
    public function checkin_ledger()
    {
        $checkins = Checkin::where('user_id', Auth::id())->orderByDesc('id')->get();
        return view('app.main.checkin-ledger', compact('checkins'));
    }
}