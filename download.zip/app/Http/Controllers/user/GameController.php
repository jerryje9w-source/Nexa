<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\GameLog;
use App\Models\UserLedger;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class GameController extends Controller
{
    private function getPrizes()
    {
        return [
            ['id' => 1, 'name' => 'Tk 5 Bonus',  'cash' => 5,  'probability' => 20, 'type' => 'low'],
            ['id' => 2, 'name' => 'Tk 10 Bonus', 'cash' => 10, 'probability' => 15, 'type' => 'low'],
            ['id' => 3, 'name' => 'Try Again',   'cash' => 0,  'probability' => 20, 'type' => 'low'],
            ['id' => 8, 'name' => 'Thanks',      'cash' => 0,  'probability' => 15, 'type' => 'low'],

            ['id' => 4, 'name' => 'Tk 20 Bonus', 'cash' => 20,  'probability' => 10, 'type' => 'high'],
            ['id' => 5, 'name' => 'Tk 50 Bonus', 'cash' => 50,  'probability' => 10, 'type' => 'high'],
            ['id' => 6, 'name' => 'iPhone 17',   'cash' => 0,   'probability' => 5,  'type' => 'high'],
            ['id' => 7, 'name' => 'Tk 100 Bonus','cash' => 100, 'probability' => 5,  'type' => 'high'],
        ];
    }

    public function index()
    {
        $user = Auth::user();
        if (!$user) {
            return redirect()->route('login')->with('error', 'অনুগ্রহ করে লগইন করুন।');
        }

        $winners = GameLog::with('user')
            ->where('amount_won', '>', 0)
            ->latest()
            ->limit(20)
            ->get()
            ->map(function ($log) {
                return (object)[
                    'phone' => $log->user->phone,
                    'amount' => $log->amount_won,
                ];
            });

        $prizesForFrontend = collect($this->getPrizes())->map(function ($prize) {
            return [
                'name' => $prize['name'],
            ];
        })->toArray();

        return view('app.main.game.index', compact('winners', 'prizesForFrontend'));
    }

    public function luckydraw(Request $request)
    {
        $user = Auth::user();

        if ($user->game_count <= 0) {
            return response()->json(['code' => 400, 'message' => 'দুঃখিত, আপনার ফ্রি স্পিন শেষ।']);
        }

        $allPrizes = $this->getPrizes();
        $lowPrizes = collect($allPrizes)->where('type', 'low')->values()->toArray();
        $highPrizes = collect($allPrizes)->where('type', 'high')->values()->toArray();

        $randomNumber = rand(0, 99);
        $chosenPrize = $randomNumber < 70
            ? $this->selectPrizeByProbability($lowPrizes)
            : $this->selectPrizeByProbability($highPrizes);

        $chosenPrizeIndex = collect($allPrizes)
            ->search(fn($p) => $p['id'] === $chosenPrize['id']);

        DB::beginTransaction();
        try {
            $user->decrement('game_count');

            // ✅ যদি কিছু জেতে
            if ($chosenPrize['cash'] > 0) {
                $user->increment('balance', $chosenPrize['cash']);
                $user->refresh();

                // ✅ লেজারে লগ করো
                UserLedger::create([
                    'user_id'     => $user->id,
                    'type'        => 'game_bonus',
                    'amount'      => $chosenPrize['cash'],
                    'trx_type'    => '+',
                    'remarks'     => 'Lucky Draw Bonus: ' . $chosenPrize['name'],
                    'final_balance' => $user->balance,
                ]);
            }

            // ✅ গেম লগ
            GameLog::create([
                'user_id'        => $user->id,
                'game_prize_id'  => $chosenPrize['id'],
                'prize_name'     => $chosenPrize['name'],
                'amount_won'     => $chosenPrize['cash'],
            ]);

            DB::commit();

            return response()->json([
                'code' => 200,
                'message' => 'অভিনন্দন! আপনি জিতেছেন: ' . $chosenPrize['name'],
                'data' => [
                    'prize_id'   => $chosenPrizeIndex,
                    'prize_name' => $chosenPrize['name'],
                    'cash'       => $user->balance,
                    'gameCount'  => $user->game_count,
                ]
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'code' => 500,
                'message' => 'একটি সমস্যা হয়েছে, অনুগ্রহ করে আবার চেষ্টা করুন।',
                'error' => $e->getMessage(),
            ]);
        }
    }

    private function selectPrizeByProbability(array $prizes)
    {
        $totalProbability = array_sum(array_column($prizes, 'probability'));
        $randNum = rand(1, $totalProbability);

        $cumulativeProbability = 0;
        foreach ($prizes as $prize) {
            $cumulativeProbability += $prize['probability'];
            if ($randNum <= $cumulativeProbability) {
                return $prize;
            }
        }
        return $prizes[array_rand($prizes)];
    }
}