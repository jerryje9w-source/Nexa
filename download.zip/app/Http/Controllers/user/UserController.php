<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\Bonus;
use App\Models\BonusLedger;
use App\Models\Deposit;
use App\Models\Package;
use App\Models\Purchase;
use App\Models\Task;
use App\Models\User;
use App\Models\UserLedger;
use App\Models\VipSlider;
use App\Models\Withdrawal;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserController extends Controller
{
    // ================= Dashboard =================
    public function dashboard()
    {
        $packages = Package::where('status', 'active')->get();
        $vips = my_vips();
        $sliders = VipSlider::where('page_type', 'home_page')->where('status', 'active')->get();
        $vipUsers = Purchase::with('user', 'package')->where('package_id', '>', 1)->inRandomOrder()->limit(10)->get();

        return view('app.main.index', compact('sliders', 'vipUsers', 'packages', 'vips'));
    }

    public function commission() { return view('app.main.commission'); }
    public function refer_commission() { return view('app.main.refer_commission'); }
    public function package_details($id)
    {
        $package = Package::find($id);
        return view('app.main.package_details', compact('package'));
    }

    public function vip()
    {
        $sliders = VipSlider::where('page_type', 'vip_page')->where('status', 'active')->get();
        $vips = Package::where('status', 'active')->get();
        $vids = my_vips();
        return view('app.main.vip', compact('sliders', 'vips', 'vids'));
    }

    public function allrecord() { return view('app.main.allrecord'); }

    public function profile()
    {
        $user = Auth::user();
        $first_level_users = User::where('ref_by', $user->ref_id)->count();
        $second_level_users = User::whereIn('ref_by', User::where('ref_by', $user->ref_id)->pluck('ref_id'))->count();
        $third_level_users = User::whereIn('ref_by', User::whereIn('ref_by', User::where('ref_by', $user->ref_id)->pluck('ref_id'))->pluck('ref_id'))->count();
        $team_size = $first_level_users + $second_level_users + $third_level_users;
        $today_income_from_table = $user->today_income;

        return view('app.main.profile', compact('team_size', 'today_income_from_table'));
    }

    public function promo() { return view('app.main.promo'); }
    public function promo_history() { return view('app.main.promo_history'); }
    public function history() { return view('app.main.history'); }
    public function account() { return view('app.main.account'); }
    public function recharge() { return view('app.main.recharge.index'); }

    public function deposit_confirm(Request $request)
    {
        $request->validate([
            'paymethod' => 'required|string',
            'transaction_id' => 'required|string|unique:deposits,transaction_id',
            'phone_number' => 'required|string',
            'amount' => 'required|numeric|min:1',
        ]);

        $model = new Deposit();
        $model->user_id = Auth::id();
        $model->method_name = $request->paymethod;
        $model->order_id = 'ORD-' . time() . '-' . Str::random(4);
        $model->transaction_id = $request->transaction_id;
        $model->number = $request->phone_number;
        $model->amount = $request->amount;
        $model->charge_amount = 0;
        $model->final_amount = $request->amount;
        $model->date = now();
        $model->status = 'pending';
        $model->save();

        return redirect()->route('user.recharge')->with('success', 'Deposit request submitted successfully.');
    }

    public function update_profile(Request $request)
    {
        $user = Auth::user();
        if($request->hasFile('photo')){
            $request->validate(['photo'=>'image|mimes:jpeg,png,jpg,gif|max:2048']);
            $path = uploadImage(false ,$request, 'photo', 'upload/profile/', 200, 200 ,$user->photo);
            $user->photo = $path;
            $user->save();
        }
        return redirect()->route('profile')->with('success', 'Profile updated successfully.');
    }

    public function personal_details() { return view('app.main.update_personal_details'); }

    public function personal_details_submit(Request $request)
    {
        $request->validate([
            'name'=> 'required|string|max:255',
            'methods'=> 'required|string',
            'number'=> 'required|string',
        ]);
        $user = Auth::user();
        $user->name = $request->name;
        $user->gateway_number = $request->number;
        $user->gateway_method = $request->methods;
        $user->save();

        Auth::setUser($user); // Force refresh user session

        return redirect()->route('user.personal-details')->with('success', 'Details updated successfully.');
    }

    // ================= Bonus Ledger =================
    public function bonus_ledger()
    {
        $bonuses = BonusLedger::with('bonus')->where('user_id', Auth::id())->latest()->paginate(15);
        return view('user.bonus_ledger', compact('bonuses'));
    }

    public function payment_ledger()
    {
        $payments = Deposit::where('user_id', Auth::id())->latest()->paginate(15);
        return view('app.main.recharge.payment-preview', compact('payments'));
    }

    public function withdraw_ledger()
    {
        $withdraws = Withdrawal::with('payment_method')->where('user_id', Auth::id())->latest()->paginate(15);
        return view('app.main.withdraw.withdraw-preview', compact('withdraws'));
    }

    public function password() { return view('app.main.password'); }

    public function changepassword(Request $request)
    {
        $request->validate([
            'current_password' => 'required',
            'new_password'     => 'required|min:6|same:confirm_password',
            'confirm_password' => 'required',
        ]);

        $user = Auth::user();

        if (Hash::check($request->current_password, $user->password)) {
            $user->update([
                'password' => Hash::make($request->new_password)
            ]);
            return back()->with('success', 'Password successfully changed.');
        } else {
            return back()->with('error', 'Current password does not match.');
        }
    }

    // ================= Task =================
    public function task()
    {
        $user = Auth::user();
        $teamStats = $this->computeTeamStats($user->id);

        return view('app.main.task', [
            'team_size' => $teamStats['size'],
            'teamDeposit' => $teamStats['deposit'],
            'first_level_users' => $teamStats['level1_users'],
        ]);
    }

    public function team()
    {
        $user = Auth::user();
        $teamStats = $this->computeTeamStats($user->id);
        return view('app.main.team', compact('teamStats'));
    }

    public function invite()
    {
        $user = Auth::user();
        $teamStats = $this->computeTeamStats($user->id);

        return view('app.main.invite', [
            'first_level_users' => $teamStats['level1_users'],
            'second_level_users' => $teamStats['level2_users'],
            'third_level_users' => $teamStats['level3_users'],
            'team_size' => $teamStats['size'],
            'lvTotalDeposit' => $teamStats['deposit'],
            'lv1Recharge' => $teamStats['level1_deposit'],
            'lv2Recharge' => $teamStats['level2_deposit'],
            'lv3Recharge' => $teamStats['level3_deposit'],
        ]);
    }

    // ================= Card/Gateway =================
    public function card() { return view('app.main.gateway_setup'); }

    public function setupGateway(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'gateway_number' => 'required|string',
            'gateway_name' => 'required|string',
        ]);

        $user = Auth::user();
        $user->realname = $request->name; // Account Name
        $user->gateway_number = $request->gateway_number;
        $user->gateway_name = $request->gateway_name;
        $user->save();

        Auth::setUser($user); // Force refresh user session

        return redirect()->route('user.withdraw')->with('success','Gateway setup successful.');
    }

    public function service() { return view('app.main.service'); }
    public function about() { return view('app.main.about'); }

    public function download_apk()
    {
        $file_path = public_path('onsemi.apk');
        if(file_exists($file_path)){
            return response()->download($file_path,'onsemi.apk');
        }
        abort(404,'File not found.');
    }

    // ================= Helper function =================
    private function computeTeamStats($userId)
    {
        $user = User::find($userId);

        // Level 1
        $level1_users = User::where('ref_by', $user->ref_id)->get();
        $level1_ids = $level1_users->pluck('id');

        // Level 2
        $level2_users = User::whereIn('ref_by', $level1_users->pluck('ref_id'))->whereNotNull('ref_by')->get();
        $level2_ids = $level2_users->pluck('id');

        // Level 3
        $level3_users = User::whereIn('ref_by', $level2_users->pluck('ref_id'))->whereNotNull('ref_by')->get();
        $level3_ids = $level3_users->pluck('id');

        // Team size
        $team_size = count($level1_users) + count($level2_users) + count($level3_users);

        // Deposit sums
        $level1_deposit = Deposit::whereIn('user_id', $level1_ids)->where('status','approved')->sum('amount');
        $level2_deposit = Deposit::whereIn('user_id', $level2_ids)->where('status','approved')->sum('amount');
        $level3_deposit = Deposit::whereIn('user_id', $level3_ids)->where('status','approved')->sum('amount');
        $total_deposit = $level1_deposit + $level2_deposit + $level3_deposit;

        return [
            'level1_users'=>$level1_users,
            'level2_users'=>$level2_users,
            'level3_users'=>$level3_users,
            'level1_deposit'=>$level1_deposit,
            'level2_deposit'=>$level2_deposit,
            'level3_deposit'=>$level3_deposit,
            'deposit'=>$total_deposit,
            'size'=>$team_size
        ];
    }
}
