<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Checkin;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class RegisteredUserController extends Controller
{
    /**
     * Show the registration view.
     */
    public function create(Request $request)
    {
        // URL থেকে ref_by নিয়ে ভিউতে পাঠাবে (যেমন: ?ref_by=123456)
        $ref_by = $request->query('ref_by');
        
        // আপনার ব্লেড ফাইলটি resources/views/app/auth/registration.blade.php তে থাকতে হবে
        return view('app.auth.registration', compact('ref_by'));
    }

    /**
     * Handle an incoming registration request.
     */
    public function store(Request $request)
    {
        // ১. ভ্যালিডেশন (ডিজাইনে ৩টি ইনপুট আছে, তাই এখানেও ৩টি যাচাই করা হচ্ছে)
        $validate = Validator::make($request->all(), [
            'phone'    => ['required', 'string', 'max:15', 'unique:users,phone'], // ইউনিক ফোন নম্বর চেক
            'password' => ['required', 'string', 'min:6'], // পাসওয়ার্ড মিনিমাম ৬ ক্যারেক্টার
            'ref_by'   => ['nullable', 'string', 'exists:users,ref_id'], // রেফার কোড যদি দেয়, তা ইউজার টেবিলে থাকতে হবে
        ], [
            'ref_by.exists' => 'The provided referral code is invalid.', // কাস্টম এরর মেসেজ
            'phone.unique'  => 'This mobile number is already registered.',
        ]);

        // ২. ভ্যালিডেশন ফেইল করলে এরর সহ ব্যাক করবে
        if ($validate->fails()){
            return redirect()->back()->withErrors($validate->errors())->withInput();
        }

        // ৩. নতুন ইউজার তৈরি (লজিক আপনার দেওয়া কোড অনুযায়ী)
        $user = User::create([
            'name'           => 'u' . $request->phone, // নামের আগে u যুক্ত হবে
            'username'       => 'user_' . Str::random(8), 
            'ref_id'         => date('d') . rand(111111, 999999), // নতুন ইউজারের জন্য ইউনিক রেফার আইডি জেনারেট
            'ref_by'         => $request->ref_by, // যার রেফারে জয়েন করছে
            'email'          => 'user' . rand(0, 999999) . Str::random(2) . '@example.com', // ফেইক ইমেইল জেনারেট
            'phone'          => $request->phone,
            'password'       => Hash::make($request->password),
            'type'           => 'user',
            'balance'        => 0,
            'game_count'     => 1, 
            'remember_token' => Str::random(30),
        ]);

        if ($user) {
            // ৪. চেকইন টেবিল ডাটা এন্ট্রি (আপনার লজিক অনুযায়ী)
            Checkin::create([
                'user_id' => $user->id,
                'date'    => now(),
                'amount'  => 0,
            ]);

            // ৫. রেফার বোনাস বা কাউন্ট আপডেট লজিক
            if ($request->filled('ref_by')) {
                $referrer = User::where('ref_id', $request->ref_by)->first();

                if ($referrer) {
                    $referrer->increment('game_count'); // রেফারকারীর গেম কাউন্ট বাড়বে
                }
            }

            // ৬. অটো লগিন এবং ড্যাশবোর্ডে রিডাইরেক্ট
            Auth::login($user);
            return redirect()->route('dashboard')->with('success', 'Registration successful!');
        } else {
            return redirect()->back()->with('error', 'Something went wrong. Please try again.');
        }
    }
}